from data import yahoo_load
from new_propensity_data import new_yahoo_load
from sklearn.model_selection import train_test_split
from trainer import Trainer
from trainer_wmf import WmfTrainer
from trainer_bpr import BprTrainer
from trainer_with_imputation import DumfTrainer
import pandas as pd
import numpy as np
from Bpr import Bpr
from evaluator import Evaluator
from evaluator import AfterLearnModel
import tensorflow as tf
import warnings
import logging
import argparse

#ExperimentOnYahooR3 Model--RMF
parser = argparse.ArgumentParser(description='rmf')
#learning_rate = 0.005
parser.add_argument('--learning_rate', type=float, default=0.005)

args = parser.parse_args()

latent_dim = 200
regu_lam = 0.0001
iters = 300
batch_size = 2**15
learning_rate = args.learning_rate
#learning_rate = 0.005
warnings.filterwarnings("ignore")
logger = logging.getLogger()
logger.setLevel("ERROR")




# train, test, test_rare, test_active, num_users, num_items = yahoo_load()
#train, test, test_rare, test_active, num_users, num_items = new_yahoo_load()
train = np.load(f'../data/train.npy')
test = np.load(f'../data/test.npy')
test_rare = np.load(f'../data/test_rare.npy')
# test_active = np.load(f'../data/test_active.npy')

trainer = Trainer(latent_dim=latent_dim, regu_lam=regu_lam, iters=iters, batch_size=batch_size,
                  learning_rate=learning_rate, num_users=15400, num_items=1000)
trainer.run(args=args, train=train, test=test, test_rare = test_rare, iters=iters, batch_size=batch_size)
evaluator = Evaluator(args=args, test=test, rare=False, active=False, name='rmf')
evaluator.evaluate(iters)
evaluator_rare = Evaluator(args=args, test=test_rare, rare=True, active=False, name='rmf')
evaluator_rare.evaluate(iters)
# evaluator_rare = Evaluator(test=test_active, rare=False, active=True, name='rmf')
# evaluator_rare.evaluate()

# ExperimentOnYahooR3 Model--WMF
# latent_dim = 200
# regu_lam = 0.0001
# iters = 300
# batch_size = 2**15
# learning_rate = 0.005
# weight = 10
#
# warnings.filterwarnings("ignore")
# tf.get_logger().setLevel("ERROR")
# # train, test, test_rare, test_active, num_users, num_items = yahoo_load()
# train = np.load(f'../data/train.npy')
# test = np.load(f'../data/test.npy')
# # test_rare = np.load(f'../data/test_rare.npy')
# test_active = np.load(f'../data/test_active.npy')
# trainer_wmf = WmfTrainer(latent_dim=latent_dim, regu_lam=regu_lam, iters=iters, batch_size=batch_size,
#                          learning_rate=learning_rate, num_users=15400, num_items=1000, weight=weight)
# trainer_wmf.run(train=train, test=test, iters=iters, batch_size=batch_size)
# # evaluator = Evaluator(test=test, rare=False, active=False, name='wmf')
# # evaluator.evaluate()
# # evaluator_rare = Evaluator(test=test_rare, rare=True, active=False, name='wmf')
# # evaluator_rare.evaluate()
# evaluator_rare = Evaluator(test=test_active, rare=False, active=True, name='wmf')
# evaluator_rare.evaluate()


# ExperimentOnYahooR3 Model--BPR
# num_ratings, num_user, num_item, train, test = yahoo_load_bpr()
# latent_dim = 30
# learning_rate = 0.005
# regu_lam = 0.0001
# iters = 300
# batch_size = 32
# Optimizer = tf.train.AdamOptimizer
# warnings.filterwarnings("ignore")
# tf.get_logger().setLevel("ERROR")
# # test_rare = np.load(f'../data/test_rare.npy')
# test_active = np.load(f'../data/test_active.npy')
# bpr = Bpr(train, test, num_user, num_item,
#           latent_dim, Optimizer, learning_rate, regu_lam)
# bpr.build_model(test, iters, batch_size)
# # evaluator = Evaluator(test=test, rare=False, active=False, name='bpr')
# # evaluator.evaluate()
# evaluator_active = Evaluator(test=test_active, rare=False, active=True, name='bpr')
# evaluator_active.evaluate()
# evaluator_rare = Evaluator(test=test_rare, rare=True, active=False, name='bpr')
# evaluator_rare.evaluate()


# ExperimentOnYahooR3 Model--DUMF
# latent_dim = 100
# regu_lam = 0.00002
# iters = 500
# batch_size = 2**15
# learning_rate = 0.0005
#
# warnings.filterwarnings("ignore")
# tf.get_logger().setLevel("ERROR")
# train, test, test_rare, num_users, num_items = yahoo_load()
# trainer = DumfTrainer(latent_dim=latent_dim, regu_lam=regu_lam, iters=iters, batch_size=batch_size,
#                       learning_rate=learning_rate, num_users=num_users, num_items=num_items)
# trainer.run(train=train, test=test, iters=iters, batch_size=batch_size)
# evaluator = Evaluator(test=test, rare=False, name='DUmf')
# evaluator.evaluate()
# evaluator_rare = Evaluator(test=test_rare, rare=True, name='DUmf')
# evaluator_rare.evaluate()
