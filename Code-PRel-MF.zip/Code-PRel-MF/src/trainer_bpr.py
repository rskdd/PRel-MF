import os
import numpy as np
import pandas as pd
from collections import defaultdict
import tensorflow as tf
from tensorflow.python.framework import ops
import random
from model import PointwiseImplicitRecommender
from model import  PairwiseRecommender
from evaluator import Evaluator


class BprTrainer:

    def __init__(
            self, latent_dim: int = 5, regu_lam: float = 1e-5, iters: int = 500,
            batch_size: int = 12, learning_rate: float = 0.1, num_users: int = 15400, num_items: int = 1000):
        self.latent_dim = latent_dim
        self.regu_lam = regu_lam
        self.batch_size = batch_size
        self.iters = iters
        self.learning_rate = learning_rate
        self.num_users = num_users
        self.num_items = num_items
        os.makedirs(f'../logs/bpr/results', exist_ok=True)

    def run(self, train, test, iters, batch_size):
        dcg = []
        map = []
        recall = []
        self.train = train
        self.items_of_user = defaultdict(set)
        self.num_rating = 0
        for u in range(0, self.num_users):
            for i in train[u]:  # interaction
                self.items_of_user[u].add(i[0])
                self.num_rating += 1
        print(self.num_rating)
        tf.set_random_seed(12345)
        ops.reset_default_graph()
        sess = tf.Session()
        rec = PairwiseRecommender(
            num_users=self.num_users, num_items=self.num_items,
            latent_dim=self.latent_dim, regu_lam=self.regu_lam, learning_rate=self.learning_rate)
        train_loss_list = []
        init_op = tf.global_variables_initializer()
        sess.run(init_op)
        np.random.seed(12345)
        print(self.num_rating // 50 // self.batch_size)
        for i in np.arange(iters):
            for _ in range(self.num_rating // 50 // self.batch_size):
                uij_train = self.get_batch()
                sess.run([rec.apply_grads_bpr],
                         feed_dict={rec.users: uij_train[:, 0],
                                    rec.pos_items: uij_train[:, 1],
                                    rec.items2: uij_train[:, 2]})
            print('Have finished epoch {}.'.format(i + 1))
            # if i % 50 == 0:
            #     u_emb, i_emb = sess.run([rec.user_embeddings, rec.item_embeddings])
            #     np.save(file=f'../logs/bpr/embeds/user_embed.npy', arr=u_emb)
            #     np.save(file=f'../logs/bpr/embeds/item_embed.npy', arr=i_emb)
            #     evaluator = Evaluator(test=test, rare=False, name='rmf')
            #     evaluator.evaluate()
            #     test_result = pd.read_csv(f'../logs/bpr/results/ranking.csv', index_col=0)
            #     dcg.append(test_result.loc['DCG@5', 'rmf'])
            #     map.append(test_result.loc['MAP@5', 'rmf'])
            #     recall.append(test_result.loc['Recall@5', 'rmf'])
            #     print(dcg)
            #     print(recall)
            #     print(map)
        os.makedirs(f'../logs/bpr/embeds/', exist_ok=True)
        u_emb, i_emb = sess.run([rec.user_embeddings, rec.item_embeddings])
        np.save(file=f'../logs/bpr/embeds/user_embed.npy', arr=u_emb)
        np.save(file=f'../logs/bpr/embeds/item_embed.npy', arr=i_emb)
        os.makedirs(f'../logs/bpr/loss/', exist_ok=True)
        np.save(file=f'../logs/bpr/loss/train.npy', arr=np.array(train_loss_list))
        sess.close()


    def get_batch(self):
        t = []
        for _ in range(self.batch_size):
            # sample a user
            _u = random.sample(range(0, self.num_users), 1)[0]
            while len(self.items_of_user[_u]) == 0:
                _u = random.sample(range(0, self.num_users), 1)[0]
            # sample a positive item
            _i = random.sample(self.items_of_user[_u], 1)[0]
            # sample a negative item
            _j = random.sample(range(0, self.num_items), 1)[0]
            while _j in self.items_of_user[_u]:
                _j = random.sample(range(1, self.num_items), 1)[0]
            t.append([_u, _i, _j])
        return np.asarray(t)

