import os
import numpy as np
import pandas as pd
import tensorflow as tf
from tensorflow.python.framework import ops
from model import PointwiseImplicitRecommender
from evaluator import Evaluator


class Trainer:

    def __init__(
            self, latent_dim: int = 5, regu_lam: float = 1e-5, iters: int = 500,
            batch_size: int = 12, learning_rate: float = 0.1, num_users: int = 15400, num_items: int = 1000):
        self.latent_dim = latent_dim
        self.regu_lam = regu_lam
        self.batch_size = batch_size
        self.iters = iters
        self.learning_rate = learning_rate
        self.num_users = num_users
        self.num_items = num_items
        os.makedirs(f'../logs/rmf/results', exist_ok=True)

    def run(self, args, train, test, test_rare, iters, batch_size):
        dcg = []
        map = []
        recall = []
        tf.set_random_seed(12345)
        ops.reset_default_graph()
        sess = tf.Session()
        rec = PointwiseImplicitRecommender(
            num_users=self.num_users, num_items=self.num_items,
            latent_dim=self.latent_dim, regu_lam=self.regu_lam, learning_rate=self.learning_rate)
        train_loss_list = []
        init_op = tf.global_variables_initializer()
        sess.run(init_op)
        np.random.seed(12345)
        train_one = train[train[:, 2] == 1]
        train_zero = train[train[:, 2] == 0]
        # train_zero[:, 2] = train_zero[:, 2] + 0.001
        for i in np.arange(iters):
            idx_1 = np.random.choice(np.arange(int(train_one.shape[0]), dtype=int), size=int(batch_size/2))
            idx_0 = np.random.choice(np.arange(int(train_zero.shape[0]), dtype=int), size=int(batch_size/2))
            train_batch = np.r_[train_one[idx_1], train_zero[idx_0]]
            # _, loss = sess.run([rec.apply_grads, rec.sum_loss],
            #                    feed_dict={rec.users: train_batch[:, 0],
            #                               rec.items: train_batch[:, 1],
            #                               rec.labels: np.expand_dims(train_batch[:, 2], 1),
            #                               rec.scores: np.expand_dims(train_batch[:, 3], 1)})


            if i % 50 == 0:
                _, loss, u_emb, i_emb = sess.run([rec.apply_grads, rec.loss, rec.user_embeddings, rec.item_embeddings],
                   feed_dict={rec.users: train_batch[:, 0],
                              rec.items: train_batch[:, 1],
                              rec.labels: np.expand_dims(train_batch[:, 2], 1),
                              rec.scores: np.expand_dims(train_batch[:, 3], 1)})
                np.save(file=f'../logs/rmf/embeds/user_embed.npy', arr=u_emb)
                np.save(file=f'../logs/rmf/embeds/item_embed.npy', arr=i_emb)
                evaluator = Evaluator(args=args, test=test, rare=False, active=False, name='rmf')
                evaluator.evaluate(i)
                evaluator_rare = Evaluator(args=args, test=test_rare, rare=True, active=False, name='rmf')
                evaluator_rare.evaluate(i)
                train_loss_list.append(loss)
            else :
                _, loss = sess.run([rec.apply_grads, rec.loss],
                   feed_dict={rec.users: train_batch[:, 0],
                              rec.items: train_batch[:, 1],
                              rec.labels: np.expand_dims(train_batch[:, 2], 1),
                              rec.scores: np.expand_dims(train_batch[:, 3], 1)})  
                train_loss_list.append(loss)
            
             
                # test_result = pd.read_csv(f'../logs/rmf/results/'+ 'iter' + str(i) +'_lr' str(args.learning_rate) + 'ranking.csv', index_col=0)
                # dcg.append(test_result.loc['DCG@5', 'rmf'])
                # map.append(test_result.loc['MAP@5', 'rmf'])
                # recall.append(test_result.loc['Recall@5', 'rmf'])
                # print(i,"DCG@5:", dcg, ", Recall@5:", recall, ", Map@5:", map)
                # print(i, test_result)
                # all_result.append(test_result)
                

        os.makedirs(f'../logs/rmf/embeds/', exist_ok=True)
        u_emb, i_emb = sess.run([rec.user_embeddings, rec.item_embeddings])
        np.save(file=f'../logs/rmf/embeds/user_embed.npy', arr=u_emb)
        np.save(file=f'../logs/rmf/embeds/item_embed.npy', arr=i_emb)
        os.makedirs(f'../logs/rmf/loss/', exist_ok=True)
        np.save(file=f'../logs/rmf/loss/train_loss.npy', arr=np.array(train_loss_list))
        # np.save(file=f'../logs/rmf/results/all_result.npy', arr=np.array(all_result))
        sess.close()

